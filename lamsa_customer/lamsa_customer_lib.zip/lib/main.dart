import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/theme/app_theme.dart';
import 'screens/home/home_screen.dart';
import 'screens/splash/splash_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'services/auth_service.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  try {
    OneSignal.initialize("e691eb75-44b7-440c-8801-ca0f54cf66a1");
    OneSignal.Notifications.requestPermission(true);
    final customerId = AuthService.instance.currentUserId;
    if (customerId != null) {
      await OneSignal.login(customerId);
    }
    await AuthService.instance.ensureSignedIn();
  } catch (e) {
    debugPrint('فشل تسجيل الدخول المجهول: $e');
  }
  runApp(const LamsaApp());
}

class LamsaApp extends StatelessWidget {
  const LamsaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'لمسة',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const HomeScreen(),
    );
  }
}